﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","ro",{title:"Interfața cu utilizatorul a Selectorului de culoare",options:"Opțiuni culoare",highlight:"Evidențiere",selected:"Culoare selectată",predefined:"Seturi de culoare predefinite",config:"Copiază această expresie în fișierul tău config.js"});